#ifndef H_CSM_ALL
#define H_CSM_ALL

#include <csm_eigen/csm.h>

#ifdef __cplusplus
namespace CSM {}
//extern "C" {
#endif

//#include "json_journal.h"
#include <csm_eigen/logging.h>
#include <csm_eigen/math_utils.h>
#include <csm_eigen/math_utils_gsl.h>

#ifdef __cplusplus
//}
#endif

#endif
